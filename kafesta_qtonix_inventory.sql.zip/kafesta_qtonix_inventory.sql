-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 22, 2021 at 01:03 AM
-- Server version: 10.3.30-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kafesta_qtonix_inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `attributes`
--

CREATE TABLE `attributes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attributes`
--

INSERT INTO `attributes` (`id`, `name`, `created_at`, `updated_at`) VALUES
(42, 'Color', '2021-04-01 15:07:52', '2021-04-01 15:07:52'),
(41, 'Size', '2021-04-01 15:07:39', '2021-04-01 15:07:39');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `purchase_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `booking_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `booking_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `booking_contact` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `booking_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_virtual_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unqid` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_price` decimal(7,2) DEFAULT NULL,
  `qty` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `purchase_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isbooking` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `booking_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `booking_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `booking_contact` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `booking_address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_virtual_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_virtual_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unqid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(7,2) NOT NULL,
  `total_price` decimal(7,2) DEFAULT NULL,
  `qty` int(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `size` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `purchase_code`, `payment`, `status`, `isbooking`, `booking_name`, `booking_email`, `booking_contact`, `booking_address`, `type`, `auth_id`, `auth_name`, `product_id`, `product_virtual_id`, `sku`, `product_name`, `product_virtual_name`, `unqid`, `price`, `total_price`, `qty`, `created_at`, `updated_at`, `size`, `color`) VALUES
(64, 'ODR818950711', 'paid', 'pending', 'pending', 'John Doe', 'manager@manager.com', '96586672870', 'Ayshford', 'Simple', '12', 'John Doe', '131', NULL, 'asdasdasd', 'Car', NULL, 'BS1620796232317', 85.58, 342.32, 4, '2021-05-12 09:14:39', '2021-07-07 14:28:07', 'Waist 42\"', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'India', '2021-03-26 15:17:44', '2021-03-26 15:17:44'),
(4, 'USA', '2021-04-19 14:49:40', '2021-04-19 14:49:40'),
(5, 'UK', '2021-04-19 14:49:43', '2021-04-19 14:49:43');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_03_26_071911_create_attributes_table', 2),
(5, '2021_03_26_092556_create_sub_attributes_table', 3),
(6, '2021_03_26_103249_create_product_categories_table', 4),
(7, '2021_03_26_105216_create_product_sub_categories_table', 5),
(8, '2021_03_26_110456_create_countries_table', 6),
(9, '2021_03_26_113602_create_products_table', 7),
(10, '2021_04_01_110312_create_product_configs_table', 8),
(11, '2021_04_02_090430_create_product_images_table', 9),
(12, '2021_04_05_051102_create_product_category_for_products_table', 10),
(13, '2021_04_05_051222_create_product_sub_category_for_products_table', 10),
(14, '2021_04_05_113349_create_carts_table', 11),
(15, '2021_04_16_102855_create_stores_table', 12),
(16, '2021_04_16_110210_create_store_houses_table', 13),
(17, '2021_04_23_051854_create_bookings_table', 14),
(18, '2021_04_23_113528_create_product_notes_table', 15);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `active_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `subcategory` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `unqid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(7,2) DEFAULT NULL,
  `stock` int(255) DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `size` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `active_status`, `type`, `category`, `subcategory`, `unqid`, `name`, `sku`, `price`, `stock`, `description`, `created_at`, `updated_at`, `size`, `color`) VALUES
(117, 'Active', 'Simple', '[\"Activity Staff\",\"Activity Staff - Seasonal\",\"Activity Staff - Annual\"]', NULL, 'BS1620660192197', 'Kingswood Zip T-Shirt', 'KW11380', 4.00, 7, 'Green Activity Instructor T-Shirt', '2021-05-10 19:26:43', '2021-05-10 19:26:43', 'XXL', 'Green'),
(130, 'Active', 'Simple', '[\"Activity Staff\",\"Activity Staff - Seasonal\",\"Office Staff\"]', NULL, 'BS1620739407472', 'asdasdsd', '112', 122.33, 12, 'qwdqwd', '2021-05-11 17:24:11', '2021-05-11 17:24:11', NULL, NULL),
(131, 'Active', 'Simple', '[\"Housekeeping\",\"Activity Staff\",\"Activity Staff - Seasonal\",\"Activity Staff - Annual\"]', NULL, 'BS1620796232317', 'Car', 'asdasdasd', 85.58, 5, 'loream lipsum', '2021-05-12 09:11:14', '2021-05-12 09:11:14', 'Waist 42\"', NULL),
(142, NULL, 'Simple', '[\"Activity Staff\"]', NULL, 'BS1625652950479', 'Test', '55ggg', 5521.00, 6, 'fgn', '2021-07-07 14:18:58', '2021-07-07 14:18:58', NULL, NULL),
(143, 'Active', 'Virtual', '[\"Catering\",\"Catering - KA\"]', NULL, 'BS1625653209295', 'ssasas', 'sasss', NULL, NULL, 'ddfdd', '2021-07-07 14:23:27', '2021-07-07 14:23:27', NULL, NULL),
(144, 'Active', 'Simple', '[\"Housekeeping\",\"Maintenance\"]', NULL, 'BS1625660675646', 'Test shirt', 'N/A', 0.00, 5, 'Test shirt for upload', '2021-07-07 16:25:19', '2021-07-07 16:25:19', 'M', 'Black'),
(148, 'Active', 'Virtual', '[\"Housekeeping\",\"Activity Staff\",\"Activity Staff - Seasonal\"]', NULL, 'BS1625741441496', 'Variable Test product', 'sku041', NULL, NULL, 'Welcome...', '2021-07-08 14:52:25', '2021-07-08 14:52:25', NULL, NULL),
(149, 'Active', 'Virtual', '[\"Housekeeping\"]', NULL, 'BS1626767569383', 'Test', '123', NULL, NULL, 'aasidoasidoiausdoiu', '2021-07-20 11:53:33', '2021-07-20 11:53:33', NULL, NULL),
(150, 'Active', 'Virtual', '[\"Housekeeping\"]', NULL, 'BS1626767657632', 'Test', 'Test', NULL, NULL, 'Test', '2021-07-20 11:54:52', '2021-07-20 11:54:52', NULL, NULL),
(151, 'Active', 'Virtual', '[\"Housekeeping\"]', NULL, 'BS1626790804171', 'Inspiring Learning - House Keeping', 'SS11', NULL, NULL, 'Size:	                    S	            M             L	            XL	  XXL	 3XL	          4XL	 5XL\r\nChest (to fit):	35/37	38/40	41/43	44/46	47/49	50/52	53/55	56/58', '2021-07-20 18:40:41', '2021-07-20 18:40:41', NULL, NULL),
(152, 'Active', 'Virtual', '[\"Activity Staff\",\"Activity Staff - Seasonal\",\"Activity Staff - Annual\"]', NULL, 'BS1626792182843', 'Adventure Team Poloshirt', 'SS11 - Green', NULL, NULL, 'Size:	                     S	             M	    L	            XL	   XXL	  3XL	 4XL	          5XL\r\nChest (to fit):	35/37	38/40	41/43	44/46	47/49	50/52	53/55	56/58', '2021-07-20 18:44:25', '2021-07-20 18:44:25', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE `product_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(15, 'Housekeeping', '2021-05-10 18:12:20', '2021-05-10 18:12:20'),
(11, 'Activity Staff', '2021-05-10 18:11:47', '2021-05-10 18:11:47'),
(13, 'Maintenance', '2021-05-10 18:12:07', '2021-05-10 18:12:07'),
(19, 'Customer Service Team', '2021-07-06 15:59:14', '2021-07-20 11:47:37'),
(18, 'Catering', '2021-05-10 18:13:46', '2021-05-10 18:13:46');

-- --------------------------------------------------------

--
-- Table structure for table `product_category_for_products`
--

CREATE TABLE `product_category_for_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `unqid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_configs`
--

CREATE TABLE `product_configs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `unqid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sellprice` int(255) DEFAULT NULL,
  `price` decimal(7,2) DEFAULT NULL,
  `stock` int(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `size` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_configs`
--

INSERT INTO `product_configs` (`id`, `unqid`, `name`, `sellprice`, `price`, `stock`, `created_at`, `updated_at`, `size`, `color`) VALUES
(259, 'BS1620276248820', 'Cotton - Black - M', 199, 199.00, 2, '2021-05-06 08:53:53', '2021-05-06 08:53:53', NULL, NULL),
(258, 'BS1620276248820', 'Cotton - Black - L', 299, 299.00, 3, '2021-05-06 08:53:53', '2021-05-06 08:53:53', NULL, NULL),
(257, 'BS1620276248820', 'Cotton - Black - XL', 399, 399.00, 7, '2021-05-06 08:53:53', '2021-05-06 08:53:53', NULL, NULL),
(256, 'BS1620276248820', 'Cotton - Yellow - M', 199, 199.00, 78, '2021-05-06 08:53:53', '2021-05-06 08:53:53', NULL, NULL),
(255, 'BS1620276248820', 'Cotton - Yellow - L', 299, 299.00, 57, '2021-05-06 08:53:53', '2021-05-06 08:53:53', NULL, NULL),
(254, 'BS1620276248820', 'Cotton - Yellow - XL', 399, 399.00, 19, '2021-05-06 08:53:53', '2021-05-06 08:53:53', NULL, NULL),
(264, 'BS1620279882289', 'Poly-Cotton - 3 KG - Yellow', 2, 2.00, 0, '2021-05-06 09:45:06', '2021-05-06 09:45:06', NULL, NULL),
(273, 'BS1620725830873', 'Polyester - Light Blue - XL', 30, 30.00, 15, '2021-05-11 13:38:50', '2021-05-11 13:38:50', NULL, NULL),
(272, 'BS1620660418820', 'Waist 32\"', 30, 30.00, 15, '2021-05-11 12:51:19', '2021-05-11 12:51:19', NULL, NULL),
(271, 'BS1620660418820', 'Waist 28\"', 30, 30.00, 15, '2021-05-11 12:50:59', '2021-05-11 12:50:59', NULL, NULL),
(270, 'BS1620660418820', 'Waist 30\"', 30, 30.00, 15, '2021-05-11 12:50:38', '2021-05-11 12:50:38', NULL, NULL),
(274, 'BS1620725830873', 'Polyester - Light Blue - L', 30, 30.00, 15, '2021-05-11 13:38:50', '2021-05-11 13:38:50', NULL, NULL),
(275, 'BS1620725830873', 'Polyester - Light Blue - M', 30, 30.00, 15, '2021-05-11 13:38:50', '2021-05-11 13:38:50', NULL, NULL),
(276, 'BS1620725830873', 'Polyester - Light Blue - S', 30, 30.00, 15, '2021-05-11 13:38:50', '2021-05-11 13:38:50', NULL, NULL),
(277, 'BS1620725830873', 'Polyester - Light Blue - XXL', 30, 30.00, 15, '2021-05-11 13:38:50', '2021-05-11 13:38:50', NULL, NULL),
(278, 'BS1620725830873', 'Polyester - Light Blue - 3XL', 30, 30.00, 15, '2021-05-11 13:38:50', '2021-05-11 13:38:50', NULL, NULL),
(279, 'BS1620725830873', 'Polyester - Light Blue - 4XL', 30, 30.00, 15, '2021-05-11 13:38:50', '2021-05-11 13:38:50', NULL, NULL),
(280, 'BS1620725830873', 'Polyester - Light Blue - 6XL', 30, 30.00, 15, '2021-05-11 13:38:50', '2021-05-11 13:38:50', NULL, NULL),
(281, 'BS1620725830873', 'Polyester - Light Blue - XS', 30, 30.00, 15, '2021-05-11 13:38:50', '2021-05-11 13:38:50', NULL, NULL),
(282, 'BS1620738048271', NULL, NULL, NULL, NULL, '2021-05-11 17:02:29', '2021-05-11 17:02:29', NULL, NULL),
(283, 'BS1620738048271', NULL, NULL, NULL, NULL, '2021-05-11 17:02:29', '2021-05-11 17:02:29', NULL, NULL),
(295, 'BS1625653209295', '.l', 600, 10.00, 25, '2021-07-07 14:26:02', '2021-07-07 14:26:02', NULL, NULL),
(297, 'BS1625741441496', 'Black - XL', 100, 700.00, 1, '2021-07-08 14:52:25', '2021-07-08 14:53:12', NULL, NULL),
(298, 'BS1625741441496', 'Black - S', 80, 700.00, 1, '2021-07-08 14:52:25', '2021-07-08 14:52:25', NULL, NULL),
(299, 'BS1625741441496', 'Black - 4XL', 70, 600.00, 1, '2021-07-08 14:52:25', '2021-07-08 14:52:25', NULL, NULL),
(300, 'BS1625741441496', 'Green - XL', 60, 500.00, 1, '2021-07-08 14:52:25', '2021-07-08 14:52:25', NULL, NULL),
(301, 'BS1625741441496', 'Green - S', 50, 400.00, 1, '2021-07-08 14:52:25', '2021-07-08 14:52:25', NULL, NULL),
(302, 'BS1625741441496', 'Green - 4XL', 40, 200.00, 1, '2021-07-08 14:52:25', '2021-07-08 14:52:25', NULL, NULL),
(303, 'BS1625741441496', 'Green - XS', 20, 169.00, 1, '2021-07-08 15:20:11', '2021-07-08 15:20:11', NULL, NULL),
(308, 'BS1626767657632', 'Black - XL', 10, 10.00, 10, '2021-07-20 11:54:52', '2021-07-20 11:54:52', NULL, NULL),
(307, 'BS1625741441496', 'Royal Blue - Waist 44\"', 50, 169.00, 1, '2021-07-09 10:08:33', '2021-07-09 10:08:33', NULL, NULL),
(309, 'BS1626767657632', 'Black - L', 20, 20.00, 20, '2021-07-20 11:54:52', '2021-07-20 11:54:52', NULL, NULL),
(310, 'BS1626767657632', 'Black - S', 30, 30.00, 30, '2021-07-20 11:55:33', '2021-07-20 11:55:33', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uniqid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `imagepath` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `uniqid`, `imagepath`, `created_at`, `updated_at`) VALUES
(216, 'BS1626792182843', 'public/serverimage/1626792265523.png', '2021-07-20 18:44:25', '2021-07-20 18:44:25'),
(215, 'BS1626790804171', 'public/serverimage/1626792041682.png', '2021-07-20 18:40:41', '2021-07-20 18:40:41'),
(214, 'BS1626767657632', 'public/serverimage/1626767692978.jpg', '2021-07-20 11:54:52', '2021-07-20 11:54:52'),
(213, 'BS1625741441496', 'public/serverimage/1625741545623.png', '2021-07-08 14:52:25', '2021-07-08 14:52:25'),
(212, 'BS1625741441496', 'public/serverimage/1625741545863.jpg', '2021-07-08 14:52:25', '2021-07-08 14:52:25'),
(211, 'BS1625741162680', 'public/serverimage/1625741246546.jpg', '2021-07-08 14:47:26', '2021-07-08 14:47:26'),
(210, 'BS1625741162680', 'public/serverimage/1625741246917.jpg', '2021-07-08 14:47:26', '2021-07-08 14:47:26'),
(209, 'BS1625741162680', 'public/serverimage/1625741196358.jpg', '2021-07-08 14:46:36', '2021-07-08 14:46:36'),
(208, 'BS1625741162680', 'public/serverimage/1625741196293.jpg', '2021-07-08 14:46:36', '2021-07-08 14:46:36'),
(207, 'BS1625741089343', 'public/serverimage/1625741137284.jpg', '2021-07-08 14:45:37', '2021-07-08 14:45:37'),
(205, 'BS1625741089343', 'public/serverimage/1625741137371.jpg', '2021-07-08 14:45:37', '2021-07-08 14:45:37'),
(206, 'BS1625741089343', 'public/serverimage/1625741137976.jpg', '2021-07-08 14:45:37', '2021-07-08 14:45:37'),
(204, 'BS1625660675646', 'public/serverimage/1625660719332.png', '2021-07-07 16:25:19', '2021-07-07 16:25:19'),
(203, 'BS1625653209295', 'public/serverimage/1625653407658.png', '2021-07-07 14:23:27', '2021-07-07 14:23:27'),
(202, 'BS1625653209295', 'public/serverimage/1625653407349.jpg', '2021-07-07 14:23:27', '2021-07-07 14:23:27'),
(200, 'BS1625652950479', 'public/serverimage/1625653118919.jpg', '2021-07-07 14:18:38', '2021-07-07 14:18:38'),
(201, 'BS1625652950479', 'public/serverimage/1625653138878.jpg', '2021-07-07 14:18:58', '2021-07-07 14:18:58'),
(198, 'BS1625652865893', 'public/serverimage/1625652898518.jpg', '2021-07-07 14:14:58', '2021-07-07 14:14:58'),
(199, 'BS1625652865893', 'public/serverimage/1625652898431.png', '2021-07-07 14:14:58', '2021-07-07 14:14:58'),
(197, 'BS1625652865893', 'public/serverimage/1625652898889.jpg', '2021-07-07 14:14:58', '2021-07-07 14:14:58'),
(196, 'BS1625652865893', 'public/serverimage/1625652898242.jpg', '2021-07-07 14:14:58', '2021-07-07 14:14:58'),
(195, 'BS1625652349751', 'public/serverimage/1625652375408.jpg', '2021-07-07 14:06:15', '2021-07-07 14:06:15'),
(194, 'BS1625652349751', 'public/serverimage/1625652375410.png', '2021-07-07 14:06:15', '2021-07-07 14:06:15'),
(193, 'BS1625652303279', 'public/serverimage/1625652345840.jpg', '2021-07-07 14:05:45', '2021-07-07 14:05:45'),
(192, 'BS1625652303279', 'public/serverimage/1625652345918.png', '2021-07-07 14:05:45', '2021-07-07 14:05:45'),
(191, 'BS1625651936962', 'public/serverimage/1625652008567.jpg', '2021-07-07 14:00:08', '2021-07-07 14:00:08'),
(190, 'BS1625651936962', 'public/serverimage/1625652008480.png', '2021-07-07 14:00:08', '2021-07-07 14:00:08'),
(189, 'BS1625651936962', 'public/serverimage/1625652008585.png', '2021-07-07 14:00:08', '2021-07-07 14:00:08'),
(188, 'BS1625651791430', 'public/serverimage/1625651828230.jpg', '2021-07-07 13:57:08', '2021-07-07 13:57:08'),
(187, 'BS1625651791430', 'public/serverimage/1625651828560.png', '2021-07-07 13:57:08', '2021-07-07 13:57:08'),
(186, 'BS1625649464840', 'public/serverimage/1625649491856.jpg', '2021-07-07 13:18:11', '2021-07-07 13:18:11'),
(185, 'BS1625649464840', 'public/serverimage/1625649491454.png', '2021-07-07 13:18:11', '2021-07-07 13:18:11'),
(184, 'BS1625648520492', 'public/serverimage/1625648558881.png', '2021-07-07 13:02:38', '2021-07-07 13:02:38'),
(183, 'BS1625648520492', 'public/serverimage/1625648558441.jpg', '2021-07-07 13:02:38', '2021-07-07 13:02:38'),
(182, 'BS1625648179659', 'public/serverimage/1625648491233.jpg', '2021-07-07 13:01:31', '2021-07-07 13:01:31'),
(181, 'BS1620796232317', 'public/serverimage/1620796274650.jpeg', '2021-05-12 09:11:14', '2021-05-12 09:11:14'),
(180, 'BS1620739407472', 'public/serverimage/1620739451228.jpeg', '2021-05-11 17:24:11', '2021-05-11 17:24:11'),
(179, 'BS1620739269844', 'public/serverimage/1620739287406.jpeg', '2021-05-11 17:21:27', '2021-05-11 17:21:27'),
(178, 'BS1620738889819', 'public/serverimage/1620738904401.jpeg', '2021-05-11 17:15:04', '2021-05-11 17:15:04'),
(177, 'BS1620738847572', 'public/serverimage/1620738872917.jpeg', '2021-05-11 17:14:32', '2021-05-11 17:14:32'),
(176, 'BS1620738581890', 'public/serverimage/1620738607880.jpeg', '2021-05-11 17:10:07', '2021-05-11 17:10:07'),
(175, 'BS1620738581890', 'public/serverimage/1620738607299.jpeg', '2021-05-11 17:10:07', '2021-05-11 17:10:07'),
(174, 'BS1620738581890', 'public/serverimage/1620738607771.jpeg', '2021-05-11 17:10:07', '2021-05-11 17:10:07'),
(173, 'BS1620738458677', 'public/serverimage/1620738495960.jpeg', '2021-05-11 17:08:15', '2021-05-11 17:08:15'),
(172, 'BS1620738048271', 'public/serverimage/1620738149591.jpeg', '2021-05-11 17:02:29', '2021-05-11 17:02:29'),
(171, 'BS1620738048271', 'public/serverimage/1620738149629.jpeg', '2021-05-11 17:02:29', '2021-05-11 17:02:29'),
(170, 'BS1620738048271', 'public/serverimage/1620738149739.jpeg', '2021-05-11 17:02:29', '2021-05-11 17:02:29'),
(169, 'BS1620725830873', 'public/serverimage/1620725930653.jpg', '2021-05-11 13:38:50', '2021-05-11 13:38:50'),
(168, 'BS1620725754673', 'public/serverimage/1620725793774.jpg', '2021-05-11 13:36:33', '2021-05-11 13:36:33'),
(167, 'BS1620723152256', 'public/serverimage/1620725691654.jpg', '2021-05-11 13:34:51', '2021-05-11 13:34:51'),
(166, 'BS1620723152256', 'public/serverimage/1620725666570.jpg', '2021-05-11 13:34:26', '2021-05-11 13:34:26'),
(165, 'BS1620660418820', 'public/serverimage/1620660525496.jpg', '2021-05-10 19:28:45', '2021-05-10 19:28:45'),
(164, 'BS1620660192197', 'public/serverimage/1620660403825.JPG', '2021-05-10 19:26:43', '2021-05-10 19:26:43'),
(163, 'BS1620656188547', 'public/serverimage/1620656425651.jpg', '2021-05-10 18:20:25', '2021-05-10 18:20:25'),
(162, 'BS1620656188547', 'public/serverimage/1620656301569.jpg', '2021-05-10 18:18:21', '2021-05-10 18:18:21'),
(161, 'BS1620279882289', 'public/serverimage/1620279906582.webp', '2021-05-06 09:45:06', '2021-05-06 09:45:06'),
(160, 'BS1620279580664', 'public/serverimage/1620279636383.webp', '2021-05-06 09:40:36', '2021-05-06 09:40:36'),
(159, 'BS1620276248820', 'public/serverimage/1620276833291.webp', '2021-05-06 08:53:53', '2021-05-06 08:53:53'),
(158, 'BS1620276248820', 'public/serverimage/1620276833396.webp', '2021-05-06 08:53:53', '2021-05-06 08:53:53'),
(157, 'BS1620276248820', 'public/serverimage/1620276833995.webp', '2021-05-06 08:53:53', '2021-05-06 08:53:53'),
(156, 'BS1620276248820', 'public/serverimage/1620276833625.webp', '2021-05-06 08:53:53', '2021-05-06 08:53:53');

-- --------------------------------------------------------

--
-- Table structure for table `product_notes`
--

CREATE TABLE `product_notes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `purchase_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_sub_categories`
--

CREATE TABLE `product_sub_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `parent_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_sub_categories`
--

INSERT INTO `product_sub_categories` (`id`, `parent_name`, `name`, `created_at`, `updated_at`) VALUES
(16, 'Women', 'Women - Kurtas & Suits', '2021-04-05 10:13:41', '2021-04-05 10:13:41'),
(13, 'Men', 'Men - Casual Shirts', '2021-04-05 10:13:16', '2021-04-05 10:13:16'),
(10, 'Kids', 'Kids - T Shirts', '2021-04-05 10:12:53', '2021-04-05 10:12:53'),
(11, 'Men', 'Men - T Shirts', '2021-04-05 10:12:58', '2021-04-05 10:12:58'),
(14, 'Men', 'Men - Formal Shirts', '2021-04-05 10:13:22', '2021-04-05 10:13:22'),
(15, 'Men', 'Men - Sweatshirts', '2021-04-05 10:13:28', '2021-04-05 10:13:28'),
(17, 'Women', 'Women - Ethnic Wear', '2021-04-05 10:13:47', '2021-04-05 10:13:47'),
(18, 'Women', 'Women - Sarees', '2021-04-05 10:13:54', '2021-04-05 10:13:54'),
(19, 'Kids', 'Kids - Shirts', '2021-04-05 10:14:20', '2021-04-05 10:14:20'),
(20, 'Kids', 'Kids - Shorts', '2021-04-05 10:14:29', '2021-04-05 10:14:29'),
(21, 'Kids', 'Kids - Jeans', '2021-04-05 10:15:09', '2021-04-05 10:15:09'),
(25, 'Activity Staff', 'Activity Staff - Seasonal', '2021-05-10 18:13:04', '2021-05-10 18:13:04'),
(27, 'Activity Staff', 'Activity Staff - Annual', '2021-05-10 18:13:30', '2021-05-10 18:13:30'),
(28, 'Catering', 'Catering - KA', '2021-05-10 18:14:11', '2021-05-10 18:14:11'),
(29, 'Catering', 'Catering - Chef', '2021-05-10 18:14:18', '2021-05-10 18:14:18');

-- --------------------------------------------------------

--
-- Table structure for table `product_sub_category_for_products`
--

CREATE TABLE `product_sub_category_for_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `unqid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subcategory` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `store_houses`
--

CREATE TABLE `store_houses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `auth_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `address2` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `person_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `person_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `person_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `store_houses`
--

INSERT INTO `store_houses` (`id`, `auth_id`, `name`, `number`, `email`, `address1`, `address2`, `postal`, `city`, `state`, `country`, `person_name`, `person_number`, `person_email`, `created_at`, `updated_at`) VALUES
(5, '12', 'Shop Now1', '45899652', 'shopnow@gmail.com', 'Ayshford', NULL, 'abc', 'Devon', 'Odisha', 'United Kingdom', 'Person Name', 'biswanath.qtonix@gmail.com', '5656456654564', '2021-04-19 09:19:20', '2021-05-01 10:41:53'),
(4, NULL, 'The Full Cart', '9658223652', 'fullcart@gmail.com', '4668 White Oak Dr', NULL, '589665', 'NY', 'NY', 'USA', 'Cecil Gutierrez', 'cecil.gutierrez@example.com', '4857774589', '2021-04-17 08:26:56', '2021-04-17 11:04:44'),
(7, '13', 'Colomendy Centre', '01352 811006', 'centre.colomendy@inspiring-learning.com', 'The Kingswood Centre', 'Colomendy', 'CH7 5LB', 'Mold', 'Denbighshire', 'Wales', 'Admin', 'centre.colomendy@inspiring-learning.com', '01352 811000', '2021-05-04 16:33:58', '2021-05-04 16:34:50'),
(8, '18', 'Staffordshire', 'Staffs01', 'center.staffordshire@inspiring-learning.com', 'The Kingswood Centre (Staffordshire)', 'Barn Lane,', 'WV7 3AW', 'Nr Albrighton', 'Wolverhampton', 'UK', 'Admin', 'center.staffordshire@inspiring-learning.com', '01902844485', '2021-05-04 16:40:22', '2021-05-10 16:07:11'),
(9, NULL, 'Dukeshouse Wood', 'DHW01', 'Centre.Dukeshouse@inspiring-learning.comcentre', 'The Kingswood Centre', 'Dukeshouse Wood,', 'NE4 1TP', 'Hexham', 'Northumberland', 'UK', 'Kirsty Forster', 'Kirsty.forster@kingswood.co.uk', '01434 602503', '2021-05-10 16:13:47', '2021-05-10 16:13:47'),
(10, NULL, 'Peak Venture', 'PV01', 'Centre.Peaks@inspiring-learning.com', 'Kingswood - Peak Venture', 'Huddersfield Road', 'S36 7GF', 'Penistone', 'Sheffield', 'South Yorkshire', 'Amy McCool', 'retail.peaks@inspiring-learning.com', '01226 762285', '2021-05-10 16:17:28', '2021-05-10 16:17:28'),
(11, NULL, 'Dearne Valley', 'DV01', 'centre.dearne@inspiring-learning.com', 'Dearne Valley', 'Denaby Main', 'DN12 4EA', 'Doncaster', 'South Yorkshire', 'United Kingdom', 'Amanda', 'centre.dearne@inspiring-learning.com', '01709 771010', '2021-05-10 17:09:23', '2021-05-10 17:27:46'),
(12, NULL, 'West Runton', 'WR01', 'Centre.Wrunton@inspiring-learning.com', 'Kingswood-West Runton', 'Cromer Road,\r\nWest Runton', 'NR27 9NF', 'Cromer', 'Norfolk', 'UK', 'Andy Day', 'Centre.Wrunton@inspiring-learning.com', '01263838384', '2021-05-10 18:59:42', '2021-05-10 18:59:42'),
(13, NULL, 'Overstrand Hall', 'OS01', 'Centre.Overstrand@inspiring-learning.com', 'Kingswood - Overstrand Hall', '48 Cromer Road', 'NR27 0JJ', 'Overstrand', 'Norfolk', 'UK', 'Andy Day', 'Centre.Overstrand@inspiring-learning.com', '01263 579373', '2021-05-10 19:03:29', '2021-05-10 19:03:29'),
(14, NULL, 'Grosvenor Hall', 'GH01', 'Centre.Grosvenor@inspiring-learning.com', 'Grosvenor Hall', NULL, 'TN25 4AJ', 'Ashford', 'Kent', 'UK', 'Nadine Castle-Pearson', 'nadine.castle-pearson@kingswood.co.uk', '01233 618250', '2021-05-10 19:05:49', '2021-05-10 19:05:49'),
(15, '20', 'Isle of Wight', 'IOW01', 'Centre.IOW@inspiring-learning.com', 'Kingswood Centre', 'Old School Buildings', 'PO35 5PH', 'Bembridge', 'Isle of Wight', 'UK', 'Athena', 'Centre.IOW@inspiring-learning.com', '01983875353', '2021-05-10 19:09:44', '2021-07-07 13:54:19');

-- --------------------------------------------------------

--
-- Table structure for table `sub_attributes`
--

CREATE TABLE `sub_attributes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `parent_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sub_attributes`
--

INSERT INTO `sub_attributes` (`id`, `parent_name`, `name`, `code`, `created_at`, `updated_at`) VALUES
(86, 'Color', 'Black', 'color_black', '2021-04-20 15:52:14', '2021-04-20 15:52:14'),
(79, 'Size', 'XL', 'size_xl', '2021-04-01 15:09:15', '2021-04-01 15:09:15'),
(77, 'Size', 'L', 'size_l', '2021-04-01 15:08:56', '2021-04-01 15:08:56'),
(76, 'Size', 'M', 'size_m', '2021-04-01 15:08:51', '2021-04-01 15:08:51'),
(75, 'Size', 'S', 'size_s', '2021-04-01 15:08:46', '2021-04-01 15:08:46'),
(74, 'Color', 'Green', 'color_green', '2021-04-01 15:08:40', '2021-04-01 15:08:40'),
(72, 'Weight', '3 KG', 'weight_3 kg', '2021-04-01 15:08:23', '2021-04-01 15:08:23'),
(71, 'Weight', '2 KG', 'weight_2 kg', '2021-04-01 15:08:11', '2021-04-01 15:08:11'),
(70, 'Weight', '1 KG', 'weight_1 kg', '2021-04-01 15:08:07', '2021-04-01 15:08:07'),
(87, 'Size', 'XXL', 'size_xxl', '2021-04-20 15:52:22', '2021-04-20 15:52:22'),
(88, 'Materials', 'Cotton', 'materials_cotton', '2021-04-20 15:52:56', '2021-04-20 15:52:56'),
(89, 'Materials', 'Polyester', 'materials_polyester', '2021-04-20 15:53:01', '2021-04-20 15:53:01'),
(90, 'Materials', 'Poly-Cotton', 'materials_poly-cotton', '2021-04-20 15:53:07', '2021-04-20 15:53:07'),
(91, 'Materials', 'Linen', 'materials_linen', '2021-04-20 15:53:12', '2021-04-20 15:53:12'),
(92, 'Materials', 'Tri-Blends', 'materials_tri-blends', '2021-04-20 15:53:27', '2021-04-20 15:53:27'),
(93, 'Size', '3XL', 'size_3xl', '2021-05-10 19:21:35', '2021-05-10 19:21:35'),
(94, 'Size', '4XL', 'size_4xl', '2021-05-10 19:21:42', '2021-05-10 19:21:42'),
(95, 'Size', '6XL', 'size_6xl', '2021-05-10 19:21:49', '2021-05-10 19:21:49'),
(96, 'Size', 'XS', 'size_xs', '2021-05-10 19:21:58', '2021-05-10 19:21:58'),
(109, 'Color', 'Royal Blue', 'color_royal blue', '2021-07-06 15:58:29', '2021-07-06 15:58:29'),
(99, 'Size', 'Waist 28\"', 'size_waist 28\"', '2021-05-11 12:47:05', '2021-05-11 12:47:05'),
(101, 'Size', 'Waist 30\"', 'size_waist 30\"', '2021-05-11 12:47:24', '2021-05-11 12:47:24'),
(102, 'Size', 'Waist 32\"', 'size_waist 32\"', '2021-05-11 12:47:35', '2021-05-11 12:47:35'),
(103, 'Size', 'Waist 34\"', 'size_waist 34\"', '2021-05-11 12:47:46', '2021-05-11 12:47:46'),
(104, 'Size', 'Waist 36\"', 'size_waist 36\"', '2021-05-11 12:47:54', '2021-05-11 12:47:54'),
(105, 'Size', 'Waist 38\"', 'size_waist 38\"', '2021-05-11 12:48:54', '2021-05-11 12:48:54'),
(106, 'Size', 'Waist 40\"', 'size_waist 40\"', '2021-05-11 12:49:02', '2021-05-11 12:49:02'),
(107, 'Size', 'Waist 42\"', 'size_waist 42\"', '2021-05-11 12:49:13', '2021-05-11 12:49:13'),
(108, 'Size', 'Waist 44\"', 'size_waist 44\"', '2021-05-11 12:49:21', '2021-05-11 12:49:21');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usertype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zipcode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `storeid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `usertype`, `email`, `contact`, `address1`, `address2`, `zipcode`, `city`, `state`, `country`, `storeid`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(5, 'Biswanath', 'Admin', 'admin@admin.com', '9658667287', 'Address1', 'Address2 (optional)', 'Postcode / Zipcode', 'City', 'State', 'Country', '5', NULL, '$2y$10$uC0DsHXKH9CRcniPmjtcfeYUcKFNapn7S0cdqXwvZQzyKQD069P6m', NULL, '2021-04-03 08:38:51', '2021-05-11 16:15:54'),
(12, 'John Doe', 'Manager', 'manager@manager.com', '96586672870', 'Ayshford', NULL, '751002', 'Devon', 'Odisha', 'United Kingdom', '8', NULL, '$2y$10$iHhFYqcEFViNN587V2AE6O.3jbhIVIoD9ViUrSzI5fUrk.TSAnpCG', NULL, '2021-04-19 09:20:02', '2021-05-11 16:37:06'),
(13, 'Colin Martin', 'Admin', 'colin.martin@inspiring-learning.com', '01352811006', 'The Kingswood Centre', 'Colomendy', 'CH7 5LB', 'Mold', 'Denbighshire', 'Wales', '7', NULL, '$2y$10$jQyukZ9oB4zBUaPzDMrMwOfTek8j8BOBG7vr7YelQjt.qTj4DT65q', NULL, '2021-05-04 16:34:50', '2021-06-30 20:39:41'),
(16, 'Andrea Hewitt', 'Admin', 'solomountain@icloud.com', 'Andrea', 'Dot Promotional Clothing', NULL, 'NG3 2NJ', 'Nottingham', NULL, NULL, NULL, NULL, '$2y$10$1Ylv0vmP/YZetwguWP.Vvu9i4epPV4yzRSTWu5GrqCZG5S8EkCN9G', NULL, '2021-05-06 18:08:10', '2021-05-06 18:08:10'),
(18, 'Test User', 'Manager', 'steve.anderson@inspiring-learning.com', '01352 811006', 'Dearne Valley', 'Denaby Main', 'DN12 4EA', 'Doncaster', 'South Yorkshire', 'United Kingdom', '8', NULL, '$2y$10$MEhTkSENSXilTohunxjahePlb1xXfjqjgx0647mkxzvuugUTgCore', NULL, '2021-05-10 16:07:11', '2021-06-30 20:37:11'),
(20, 'Athena Taylor', 'Manager', 'Centre.IOW@inspiring-learning.com', '01983 875353', 'Kingswood- Isle of Wight', 'Old School Buildings', 'PO35 5PH', 'Bembridge', 'Isle of Wight', 'United Kingdom', '5', NULL, '$2y$10$7LUpppgW1dkkVzyBL0e7Te.sCDJmiZy.2s9qjK46TROp6ITMai/ha', NULL, '2021-05-11 14:57:01', '2021-05-11 16:08:34');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attributes`
--
ALTER TABLE `attributes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_category_for_products`
--
ALTER TABLE `product_category_for_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_configs`
--
ALTER TABLE `product_configs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_notes`
--
ALTER TABLE `product_notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_sub_categories`
--
ALTER TABLE `product_sub_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_sub_category_for_products`
--
ALTER TABLE `product_sub_category_for_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `store_houses`
--
ALTER TABLE `store_houses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_attributes`
--
ALTER TABLE `sub_attributes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attributes`
--
ALTER TABLE `attributes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=153;

--
-- AUTO_INCREMENT for table `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `product_category_for_products`
--
ALTER TABLE `product_category_for_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `product_configs`
--
ALTER TABLE `product_configs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=311;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=217;

--
-- AUTO_INCREMENT for table `product_notes`
--
ALTER TABLE `product_notes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `product_sub_categories`
--
ALTER TABLE `product_sub_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `product_sub_category_for_products`
--
ALTER TABLE `product_sub_category_for_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `store_houses`
--
ALTER TABLE `store_houses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `sub_attributes`
--
ALTER TABLE `sub_attributes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
